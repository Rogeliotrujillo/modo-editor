import { Product } from '../types';

// 1. Configurable limits (constants)
export const MAX_STORE_SPACE_MB = 40; // 40 MB maximum per store
export const MAX_PHOTO_SIZE_KB = 500; // 500 KB maximum per picture
export const MAX_PHOTOS_PER_PRODUCT = 3; // Maximum of 3 pictures per product
export const AUTO_COMPRESS_THRESHOLD_KB = 100; // Automatic compression if image size exceeds 100 KB

/**
 * Calculates raw size of an image in KB.
 * For Base64 strings, computes based on encoded string size.
 * For standard external preset URLs (e.g., source.unsplash.com), simulates a realistic 125 KB.
 */
export function obtenerTamanioImagenKB(imageStr: string): number {
  if (!imageStr) return 0;
  if (imageStr.startsWith('data:')) {
    // base64 size estimation formula: (string length * 0.75) / 1024
    const base64Content = imageStr.split(',')[1] || '';
    return (base64Content.length * 0.75) / 1024;
  }
  // External assets mock: assume average 125 KB
  return 125;
}

/**
 * Calculates total space used by all catalog products in Megabytes (MB).
 * Returns a number (e.g. 12.35). Including a baseline static footprint (e.g. 2.4 MB)
 * for structural database schemas and website design layout meta assets.
 */
export function calcularEspacioUsado(products: Product[]): number {
  let totalKB = 0;
  products.forEach((p) => {
    totalKB += obtenerTamanioImagenKB(p.image);
    if (p.images) {
      p.images.forEach((img) => {
        totalKB += obtenerTamanioImagenKB(img);
      });
    }
  });
  
  const baseSpaceMB = 5.25; // Simulated baseline for site code, styles, & db structure
  const productsSpaceMB = totalKB / 1024;
  return parseFloat((baseSpaceMB + productsSpaceMB).toFixed(2));
}

/**
 * Determines whether adding a new image will exceed the 40 MB threshold.
 */
export function verificarLimite(products: Product[], nuevaImagenBase64: string): boolean {
  const currentUsedMB = calcularEspacioUsado(products);
  const newImgSizeMB = obtenerTamanioImagenKB(nuevaImagenBase64) / 1024;
  return (currentUsedMB + newImgSizeMB) > MAX_STORE_SPACE_MB;
}

/**
 * Checks if the store's total space usage exceeds or matches the max limit.
 */
export function bloquearSubida(products: Product[]): boolean {
  return calcularEspacioUsado(products) >= MAX_STORE_SPACE_MB;
}

/**
 * Compressed is triggered if a base64 image exceeds 100 KB.
 * Uses canvas rendering client-side to dynamically shrink pixel dimensions and JPEG quality.
 * Aggressively scales down the dimensions and lowers quality recursively to guarantee a final size <= 100 KB.
 */
export function comprimirImagenBase64(
  base64Str: string,
  quality: number = 0.8,
  maxWidth: number = 800
): Promise<{ output: string; originalSizeKB: number; compressedSizeKB: number; compressed: boolean }> {
  const originalSizeKB = obtenerTamanioImagenKB(base64Str);
  
  if (originalSizeKB <= AUTO_COMPRESS_THRESHOLD_KB) {
    return Promise.resolve({
      output: base64Str,
      originalSizeKB,
      compressedSizeKB: originalSizeKB,
      compressed: false
    });
  }

  return new Promise((resolve) => {
    const img = new Image();
    img.src = base64Str;
    img.onload = () => {
      let width = img.width;
      let height = img.height;

      // Restructure size constraints maintaining aspect ratio
      if (width > maxWidth) {
        height = (maxWidth / width) * height;
        width = maxWidth;
      }

      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;

      const ctx = canvas.getContext('2d');
      if (!ctx) {
        resolve({
          output: base64Str,
          originalSizeKB,
          compressedSizeKB: originalSizeKB,
          compressed: false
        });
        return;
      }

      ctx.drawImage(img, 0, 0, width, height);
      
      // JPEG supports quality-based scaling. High compression factor.
      const compressedData = canvas.toDataURL('image/jpeg', quality);
      const newSizeKB = obtenerTamanioImagenKB(compressedData);

      // If still exceeding 100 KB and we have scope to make it smaller, adjust parameters and recurse
      if (newSizeKB > AUTO_COMPRESS_THRESHOLD_KB) {
        let nextQuality = quality;
        let nextMaxWidth = maxWidth;

        if (quality > 0.3) {
          nextQuality = parseFloat((quality - 0.15).toFixed(2));
        } else if (maxWidth > 120) {
          nextMaxWidth = Math.round(maxWidth * 0.75);
          nextQuality = 0.35; // keep reasonable quality, but prioritize scaling down
        } else if (quality > 0.1) {
          nextQuality = 0.1;
          nextMaxWidth = 100; // ultimate backup
        } else {
          // Absolute minimum reached, return best attempt
          resolve({
            output: compressedData,
            originalSizeKB,
            compressedSizeKB: newSizeKB,
            compressed: true
          });
          return;
        }

        comprimirImagenBase64(base64Str, nextQuality, nextMaxWidth).then(resolve);
      } else {
        resolve({
          output: compressedData,
          originalSizeKB,
          compressedSizeKB: newSizeKB,
          compressed: true
        });
      }
    };
    img.onerror = () => {
      resolve({
        output: base64Str,
        originalSizeKB,
        compressedSizeKB: originalSizeKB,
        compressed: false
      });
    };
  });
}
